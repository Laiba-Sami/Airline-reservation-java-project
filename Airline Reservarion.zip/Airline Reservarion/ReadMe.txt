Run the LoginPage file to start the project.

User-name is: admin
Password is: admin